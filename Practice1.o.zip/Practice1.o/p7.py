#alphabet or not
char=(input("enter the alphabet"))
if(char>='A' and char<='Z' or char>='a' and char<='z'):
    print("given char is alphabet")
else:
    print("given char is not a alphabet")
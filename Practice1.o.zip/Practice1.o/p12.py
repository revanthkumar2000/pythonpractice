for i in range(50,66,5):
    print(i,end="  ")
print()
for j in range(10,50,10):
    print(j,end="  ")
print()
for k in range (20,100,20):
    print(k,end="  ")
print()
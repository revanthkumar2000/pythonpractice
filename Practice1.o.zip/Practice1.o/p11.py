#to display week based on weekday
weekday=int(input("enter the weekday"))
if(weekday==1):
    print("monday")
elif(weekday==2):
    print("tuesday")
elif(weekday==3):
    print("wednesday")
elif(weekday==4):
    print("thursday")
elif(weekday==5):
    print("friday")
elif(weekday==6):
    print("saturday")
elif(weekday==7):
    print("sunday")
else:
    print("enter the number b/w 1-7")
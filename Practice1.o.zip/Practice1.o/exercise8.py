list=[1,2,3,4,5,6,7]
print("print the original list is :",list)
list.reverse()
print("the reverse order is :" ,list)
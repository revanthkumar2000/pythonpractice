#upper case or lower case
ch=(input("enter the char"))
if(ch>='A' and ch<='Z'):
    print("upper casae letter")
elif(ch>='a' and ch<='z'):
    print("lower case letter")
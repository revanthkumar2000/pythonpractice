num=int(input("enter the max value"))
sum=0
for i in range(2,num+1,2):
    sum=sum+i
print(sum)
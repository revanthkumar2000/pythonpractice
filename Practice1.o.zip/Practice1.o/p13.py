for i in range(0,4):
    print("*",end="  ")
print()
for j in range(3):
    print("*",end="  ")
print()
for k in range(0,2):
    print("*",end="  ")
print()
for i in range(1):
    print("*",end="  ")
print()
    
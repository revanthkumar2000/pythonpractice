import string
for i in string.ascii_lowercase:
    print(i, end="")
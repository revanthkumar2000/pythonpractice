#check number is +ve or -ve or zero
num=int(input("enter the number"))
if(num>0):
    print("number is +ve")
elif(num<0):
    print("number is -ve")
else:
    print("number is zero")
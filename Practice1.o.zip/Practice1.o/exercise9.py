min=int(input("enter the min value"))
max=int(input("enter the max value"))
for i in range(min,max+1,1):
    print(i,end=" ")
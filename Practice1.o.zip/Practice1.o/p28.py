list1=[]
num=int(input("enterthe size of  list"))
for i in range(0,num):
    data=int(input("enter the elements:"))
    list1.append(data)
print(list1)
#vowel or not
char=(input("enter the char"))
if(char=='A' or char=='a' or char=='E' or char=='e' or char=='I' or char=='i' or char=='O' or char=='o' or char=='U' or char=='u'):
    print("given char is vowel")
else:
    print("given char is a consonant")
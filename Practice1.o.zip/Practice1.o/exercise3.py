num1=int(input("enter the minimum value"))
num2=int(input("enter the maximum value"))
sum=0
for i in range(num1,num2+1,1):
    sum=sum+i
print(sum)
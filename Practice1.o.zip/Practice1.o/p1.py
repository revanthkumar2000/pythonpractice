#Maximum num b/w 2 number
num1=int(input("enter the first number"))
num2=int(input("enter the second number"))
if(num1>num2):
    print("maximum number is",num1)
else:
    print("maximum number is ",num2)
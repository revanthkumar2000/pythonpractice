num1=int(input("enter max value"))
sum=0
for i in range(1,num1+1,2):
    sum=sum+i
print(sum)